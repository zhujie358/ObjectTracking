/*
 * kalmanfilter.c
 *
 * Code generation for function 'kalmanfilter'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "kalman_loop.h"
#include "kalmanfilter.h"
#include "kalman_loop_data.h"

/* Function Definitions */
void kalmanfilter_init(void)
{
  int32_T i;
  for (i = 0; i < 6; i++) {
    x_est[i] = 0.0;
  }

  memset(&p_est[0], 0, 36U * sizeof(real_T));
}

/* End of code generation (kalmanfilter.c) */
