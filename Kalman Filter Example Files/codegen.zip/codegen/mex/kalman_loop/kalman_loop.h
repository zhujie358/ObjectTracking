/*
 * kalman_loop.h
 *
 * Code generation for function 'kalman_loop'
 *
 */

#ifndef __KALMAN_LOOP_H__
#define __KALMAN_LOOP_H__

/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "kalman_loop_types.h"

/* Function Declarations */
extern void kalman_loop(const emlrtStack *sp, const real_T z[200000], real_T y
  [200000]);

#endif

/* End of code generation (kalman_loop.h) */
