/*
 * _coder_kalman_loop_api.h
 *
 * Code generation for function '_coder_kalman_loop_api'
 *
 */

#ifndef ___CODER_KALMAN_LOOP_API_H__
#define ___CODER_KALMAN_LOOP_API_H__

/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "kalman_loop_types.h"

/* Function Declarations */
extern void kalman_loop_api(const mxArray * const prhs[1], const mxArray *plhs[1]);

#endif

/* End of code generation (_coder_kalman_loop_api.h) */
