/*
 * kalman_loop.c
 *
 * Code generation for function 'kalman_loop'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "kalman_loop.h"
#include "eml_warning.h"
#include "kalman_loop_data.h"

/* Variable Definitions */
static emlrtRSInfo emlrtRSI = { 8, "kalman_loop",
  "P:\\ObjectTracking-master\\coderdemo_kalman_filter2\\kalman_loop.m" };

static emlrtRSInfo b_emlrtRSI = { 26, "kalmanfilter",
  "P:\\ObjectTracking-master\\coderdemo_kalman_filter2\\kalmanfilter.m" };

static emlrtRSInfo c_emlrtRSI = { 1, "mldivide",
  "C:\\Program Files\\MATLAB\\R2014a\\toolbox\\eml\\lib\\matlab\\ops\\mldivide.p"
};

static emlrtRSInfo d_emlrtRSI = { 54, "eml_lusolve",
  "C:\\Program Files\\MATLAB\\R2014a\\toolbox\\eml\\lib\\matlab\\eml\\eml_lusolve.m"
};

static emlrtRSInfo e_emlrtRSI = { 155, "eml_lusolve",
  "C:\\Program Files\\MATLAB\\R2014a\\toolbox\\eml\\lib\\matlab\\eml\\eml_lusolve.m"
};

static emlrtRSInfo f_emlrtRSI = { 76, "eml_lusolve",
  "C:\\Program Files\\MATLAB\\R2014a\\toolbox\\eml\\lib\\matlab\\eml\\eml_lusolve.m"
};

/* Function Definitions */
void kalman_loop(const emlrtStack *sp, const real_T z[200000], real_T y[200000])
{
  real_T x_prd[6];
  real_T B[12];
  real_T b_y[2];
  int32_T n;
  int8_T Q[36];
  int32_T r2;
  real_T a[36];
  int32_T k;
  static const int8_T b_a[36] = { 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0,
    0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 1 };

  int32_T i0;
  real_T p_prd[36];
  real_T a21;
  int32_T r1;
  static const int8_T b[36] = { 1, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0,
    1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1 };

  real_T c_a[12];
  static const int8_T d_a[12] = { 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0 };

  real_T S[4];
  static const int8_T b_b[12] = { 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0 };

  static const int16_T R[4] = { 1000, 0, 0, 1000 };

  real_T a22;
  real_T klm_gain[12];
  real_T b_z[2];
  emlrtStack st;
  emlrtStack b_st;
  emlrtStack c_st;
  emlrtStack d_st;
  emlrtStack e_st;
  emlrtStack f_st;
  st.prev = sp;
  st.tls = sp->tls;
  b_st.prev = &st;
  b_st.tls = st.tls;
  c_st.prev = &b_st;
  c_st.tls = b_st.tls;
  d_st.prev = &c_st;
  d_st.tls = c_st.tls;
  e_st.prev = &d_st;
  e_st.tls = d_st.tls;
  f_st.prev = &e_st;
  f_st.tls = e_st.tls;

  /*    Copyright 2010 The MathWorks, Inc. */
  /*  Call Kalman estimator in the loop for large data set testing */
  /*  Initialize output */
  for (n = 0; n < 100000; n++) {
    /*  Output in the loop */
    st.site = &emlrtRSI;

    /*    Copyright 2010 The MathWorks, Inc. */
    /*  Initialize state transition matrix */
    /*      % [x  ] */
    /*      % [y  ] */
    /*      % [Vx] */
    /*      % [Vy] */
    /*      % [Ax] */
    /*  [Ay] */
    /*  Initialize measurement matrix */
    for (r2 = 0; r2 < 36; r2++) {
      Q[r2] = 0;
    }

    for (k = 0; k < 6; k++) {
      Q[k + 6 * k] = 1;

      /*  Initial state conditions */
      /*  Predicted state and covariance */
      x_prd[k] = 0.0;
      for (r2 = 0; r2 < 6; r2++) {
        x_prd[k] += (real_T)b_a[k + 6 * r2] * x_est[r2];
      }

      for (r2 = 0; r2 < 6; r2++) {
        a[k + 6 * r2] = 0.0;
        for (i0 = 0; i0 < 6; i0++) {
          a[k + 6 * r2] += (real_T)b_a[k + 6 * i0] * p_est[i0 + 6 * r2];
        }
      }
    }

    for (r2 = 0; r2 < 6; r2++) {
      for (i0 = 0; i0 < 6; i0++) {
        a21 = 0.0;
        for (r1 = 0; r1 < 6; r1++) {
          a21 += a[r2 + 6 * r1] * (real_T)b[r1 + 6 * i0];
        }

        p_prd[r2 + 6 * i0] = a21 + (real_T)Q[r2 + 6 * i0];
      }
    }

    /*  Estimation */
    for (r2 = 0; r2 < 2; r2++) {
      for (i0 = 0; i0 < 6; i0++) {
        c_a[r2 + (i0 << 1)] = 0.0;
        for (r1 = 0; r1 < 6; r1++) {
          c_a[r2 + (i0 << 1)] += (real_T)d_a[r2 + (r1 << 1)] * p_prd[i0 + 6 * r1];
        }
      }
    }

    for (r2 = 0; r2 < 2; r2++) {
      for (i0 = 0; i0 < 2; i0++) {
        a21 = 0.0;
        for (r1 = 0; r1 < 6; r1++) {
          a21 += c_a[r2 + (r1 << 1)] * (real_T)b_b[r1 + 6 * i0];
        }

        S[r2 + (i0 << 1)] = a21 + (real_T)R[r2 + (i0 << 1)];
      }
    }

    for (r2 = 0; r2 < 2; r2++) {
      for (i0 = 0; i0 < 6; i0++) {
        B[r2 + (i0 << 1)] = 0.0;
        for (r1 = 0; r1 < 6; r1++) {
          B[r2 + (i0 << 1)] += (real_T)d_a[r2 + (r1 << 1)] * p_prd[i0 + 6 * r1];
        }
      }
    }

    b_st.site = &b_emlrtRSI;
    c_st.site = &c_emlrtRSI;
    d_st.site = &d_emlrtRSI;
    if (muDoubleScalarAbs(S[1]) > muDoubleScalarAbs(S[0])) {
      r1 = 1;
      r2 = 0;
    } else {
      r1 = 0;
      r2 = 1;
    }

    a21 = S[r2] / S[r1];
    a22 = S[2 + r2] - a21 * S[2 + r1];
    if ((a22 == 0.0) || (S[r1] == 0.0)) {
      e_st.site = &e_emlrtRSI;
      f_st.site = &f_emlrtRSI;
      eml_warning(&f_st);
    }

    for (k = 0; k < 6; k++) {
      c_a[1 + (k << 1)] = (B[r2 + (k << 1)] - B[r1 + (k << 1)] * a21) / a22;
      c_a[k << 1] = (B[r1 + (k << 1)] - c_a[1 + (k << 1)] * S[2 + r1]) / S[r1];
    }

    for (r2 = 0; r2 < 2; r2++) {
      for (i0 = 0; i0 < 6; i0++) {
        klm_gain[i0 + 6 * r2] = c_a[r2 + (i0 << 1)];
      }
    }

    /*  Estimated state and covariance */
    for (r2 = 0; r2 < 2; r2++) {
      a21 = 0.0;
      for (i0 = 0; i0 < 6; i0++) {
        a21 += (real_T)d_a[r2 + (i0 << 1)] * x_prd[i0];
      }

      b_z[r2] = z[r2 + (n << 1)] - a21;
    }

    for (r2 = 0; r2 < 6; r2++) {
      a21 = 0.0;
      for (i0 = 0; i0 < 2; i0++) {
        a21 += klm_gain[r2 + 6 * i0] * b_z[i0];
      }

      x_est[r2] = x_prd[r2] + a21;
    }

    for (r2 = 0; r2 < 6; r2++) {
      for (i0 = 0; i0 < 6; i0++) {
        a[r2 + 6 * i0] = 0.0;
        for (r1 = 0; r1 < 2; r1++) {
          a[r2 + 6 * i0] += klm_gain[r2 + 6 * r1] * (real_T)d_a[r1 + (i0 << 1)];
        }
      }
    }

    for (r2 = 0; r2 < 6; r2++) {
      for (i0 = 0; i0 < 6; i0++) {
        a21 = 0.0;
        for (r1 = 0; r1 < 6; r1++) {
          a21 += a[r2 + 6 * r1] * p_prd[r1 + 6 * i0];
        }

        p_est[r2 + 6 * i0] = p_prd[r2 + 6 * i0] - a21;
      }
    }

    /*  Compute the estimated measurements */
    for (r2 = 0; r2 < 2; r2++) {
      b_y[r2] = 0.0;
      for (i0 = 0; i0 < 6; i0++) {
        b_y[r2] += (real_T)d_a[r2 + (i0 << 1)] * x_est[i0];
      }
    }

    /*  of the function */
    for (r2 = 0; r2 < 2; r2++) {
      y[r2 + (n << 1)] = b_y[r2];
    }

    emlrtBreakCheckFastR2012b(emlrtBreakCheckR2012bFlagVar, sp);
  }
}

/* End of code generation (kalman_loop.c) */
