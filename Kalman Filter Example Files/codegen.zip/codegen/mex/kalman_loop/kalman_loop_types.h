/*
 * kalman_loop_types.h
 *
 * Code generation for function 'kalman_loop'
 *
 */

#ifndef __KALMAN_LOOP_TYPES_H__
#define __KALMAN_LOOP_TYPES_H__

/* Include files */
#include "rtwtypes.h"

#endif
/* End of code generation (kalman_loop_types.h) */
