/*
 * kalman_loop_data.c
 *
 * Code generation for function 'kalman_loop_data'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "kalman_loop.h"
#include "kalman_loop_data.h"

/* Variable Definitions */
const volatile char_T *emlrtBreakCheckR2012bFlagVar;
real_T x_est[6];
real_T p_est[36];

/* End of code generation (kalman_loop_data.c) */
