/*
 * File: kalmanfilter.h
 *
 * MATLAB Coder version            : 2.6
 * C/C++ source code generated on  : 18-Feb-2015 11:47:06
 */

#ifndef __KALMANFILTER_H__
#define __KALMANFILTER_H__

/* Include files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "kalmanfilter_types.h"

/* Function Declarations */
extern void kalmanfilter(const double z[2], double y[2]);
extern void kalmanfilter_init(void);

#endif

/*
 * File trailer for kalmanfilter.h
 *
 * [EOF]
 */
