/*
 * File: kalmanfilter_terminate.c
 *
 * MATLAB Coder version            : 2.6
 * C/C++ source code generated on  : 18-Feb-2015 11:47:06
 */

/* Include files */
#include "rt_nonfinite.h"
#include "kalmanfilter.h"
#include "kalmanfilter_terminate.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void kalmanfilter_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for kalmanfilter_terminate.c
 *
 * [EOF]
 */
