/* 
 * File: kalmanfilter_types.h 
 *  
 * MATLAB Coder version            : 2.6 
 * C/C++ source code generated on  : 18-Feb-2015 11:47:06 
 */

#ifndef __KALMANFILTER_TYPES_H__
#define __KALMANFILTER_TYPES_H__

/* Include files */
#include "rtwtypes.h"

#endif
/* 
 * File trailer for kalmanfilter_types.h 
 *  
 * [EOF] 
 */
