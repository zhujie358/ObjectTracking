/* 
 * File: _coder_kalmanfilter_info.h 
 *  
 * MATLAB Coder version            : 2.6 
 * C/C++ source code generated on  : 18-Feb-2015 11:47:06 
 */

#ifndef ___CODER_KALMANFILTER_INFO_H__
#define ___CODER_KALMANFILTER_INFO_H__
/* Include files */
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

#endif
/* 
 * File trailer for _coder_kalmanfilter_info.h 
 *  
 * [EOF] 
 */
