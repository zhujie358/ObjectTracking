/* 
 * File: _coder_kalmanfilter_api.h 
 *  
 * MATLAB Coder version            : 2.6 
 * C/C++ source code generated on  : 18-Feb-2015 11:47:06 
 */

#ifndef ___CODER_KALMANFILTER_API_H__
#define ___CODER_KALMANFILTER_API_H__
/* Include files */
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"

/* Function Declarations */
extern void kalmanfilter_initialize(emlrtContext *aContext);
extern void kalmanfilter_terminate(void);
extern void kalmanfilter_atexit(void);
extern void kalmanfilter_api(const mxArray *prhs[1], const mxArray *plhs[1]);
extern void kalmanfilter(double z[2], double y[2]);
extern void kalmanfilter_xil_terminate(void);

#endif
/* 
 * File trailer for _coder_kalmanfilter_api.h 
 *  
 * [EOF] 
 */
