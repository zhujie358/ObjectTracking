/*
 * File: kalmanfilter_terminate.h
 *
 * MATLAB Coder version            : 2.6
 * C/C++ source code generated on  : 18-Feb-2015 11:47:06
 */

#ifndef __KALMANFILTER_TERMINATE_H__
#define __KALMANFILTER_TERMINATE_H__

/* Include files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "kalmanfilter_types.h"

/* Function Declarations */
extern void kalmanfilter_terminate(void);

#endif

/*
 * File trailer for kalmanfilter_terminate.h
 *
 * [EOF]
 */
