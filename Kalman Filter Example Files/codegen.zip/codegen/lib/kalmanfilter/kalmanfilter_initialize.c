/*
 * File: kalmanfilter_initialize.c
 *
 * MATLAB Coder version            : 2.6
 * C/C++ source code generated on  : 18-Feb-2015 11:47:06
 */

/* Include files */
#include "rt_nonfinite.h"
#include "kalmanfilter.h"
#include "kalmanfilter_initialize.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void kalmanfilter_initialize(void)
{
  rt_InitInfAndNaN(8U);
  kalmanfilter_init();
}

/*
 * File trailer for kalmanfilter_initialize.c
 *
 * [EOF]
 */
